#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np


# In[2]:


trxn=pd.read_csv("Retail_Data_Transactions.csv")
trxn


# In[3]:


response=pd.read_csv("Retail_data_response.csv")
response


# In[4]:


df=trxn.merge(response,on='customer_id', how='left')
df


# In[5]:


df.dtypes


# In[6]:


df.shape


# In[13]:


df.head()


# In[7]:


df.tail()


# In[8]:


df.describe()


# In[9]:


df.isnull().sum()


# In[12]:


df=df.dropna()


# In[10]:


df


# In[13]:


df['trans_date']=pd.to_datetime(df['trans_date'])
df['response']=df['response'].astype('int64')


# In[14]:


df


# In[15]:


set(df['response'])


# In[16]:


df.dtypes


# In[17]:


#outliers
# z score 
from scipy import stats
z_score=np.abs(stats.zscore(df['tran_amount']))
# set threshold
threshold=3
outliers=z_score>threshold
print(df[outliers])


# In[18]:


#outliers
# z score 
from scipy import stats
z_score=np.abs(stats.zscore(df['response']))
# set threshold
threshold=3
outliers=z_score>threshold
print(df[outliers])


# In[19]:


import matplotlib.pyplot as pl
import seaborn as sns
sns.boxplot(x=df['response'])
pl.show()


# In[36]:


sns.boxplot(x=df['tran_amount'])
pl.show()


# In[20]:


df['month']=df['trans_date'].dt.month


# In[38]:


df


# In[21]:


monthly_sal=df.groupby('month')['tran_amount'].sum()
monthly_sal=monthly_sal.sort_values(ascending=False).reset_index().head(3)


# monthly_sal

# In[22]:


monthly_sal


# In[25]:


customer_count=df['customer_id'].value_counts().reset_index()
customer_count.columns=['customer_id','count']
top=customer_count.sort_values(by='count',ascending=False).head(5)
top


# In[26]:


sns.barplot(x='customer_id',y='count', data=top)
pl.show()


# In[30]:


# customer having the higgest value of order
customer_sales=df.groupby('customer_id').sum().reset_index()

top5sal=customer_sales.sort_values(by='tran_amount',ascending=False).head(5)
top5sal


# In[31]:


sns.barplot(x='customer_id',y='tran_amount', data=top5sal)
pl.show()


# In[43]:


# time series analysis
import matplotlib.dates as mdates
df['month_year']=df['trans_date'].dt.to_period('M')
monthly_sal=df.groupby('month_year')['tran_amount'].sum()
type(monthly_sal.index)

monthly_sal.index=monthly_sal.index.to_timestamp()
pl.figure(figsize=(12,6))
pl.plot(monthly_sal.index,monthly_sal.values)
pl.show()

pl.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))

pl.gca().xaxis.set_major_locator(mdates.MonthLocator(interval=6))
pl.xlabel('monthly year')
pl.ylabel('sales')
pl.title('monthly sales')
pl.xticks(rotation=45)
pl.tight_layout()
pl.show()


# In[34]:


df


# In[47]:


# cohort segmentation
# recency
recency=df.groupby('customer_id')['trans_date'].max()
# ferequency
frequency=df.groupby('customer_id')['trans_date'].count()
# monetary
monetary=df.groupby('customer_id')['tran_amount'].sum()

#combine
rfm=pd.DataFrame({'recency':recency,'frequency':frequency,'monetary':monetary})
rfm


# In[48]:


def segment_customer(row):
    if row['recency'].year>=2012 and row['frequency']>=15 and row['monetary']>1000:
        return 'P0'
    elif (2011<=row['recency'].year<2012)and (10<row['frequency']<15) and (500<=row['monetary']<=1000):
        return 'P1'
    else:
        return 'P2'
rfm['Segment']=rfm.apply(segment_customer,axis=1)
rfm


# In[49]:


#count the numbers of churned and cative customers
churn_counts=df['response'].value_counts()
#plot
churn_counts.plot(kind='bar')


# In[52]:


# analyzing the top customer
top_5_cus= monetary.sort_values(ascending=False).head(5).index
top_cust_df=df[df['customer_id'].isin(top_5_cus)]
top_customers_sales=top_cust_df.groupby(['customer_id','month_year'])['tran_amount'].sum().unstack(level=0)
top_customers_sales.plot(kind='line')


# In[53]:


df.to_csv('Maindata.csv')


# In[54]:


rfm.to_csv('AddAnalysis.csv')


# In[ ]:




